```text
# Project     : awx_deploy
#
# Playbook    : awx2awx-CREDENTIAL.yml, awx2awx-INVENTORIES.yml, awx2awx-JOB.yml, awx2awx-PROJECT.yml, awx2awx-WORKFLOW.yml
# Version     : V0.1
# Author      : ESI
#             : ansible-playbook --ask-v awx2awx-INVENTORIES.yml \
  -e "ConfFileName=config/liste_brocade_zoning.yml" \
   \
    
# Cmd Line    : ansible-playbook awx2awx-CREDENTIAL.yml --ask-v -e "configFile=config/liste_brocade_zoning.yml" -e "Export=true"
# Cmd Line    : ansible-playbook awx2awx-CREDENTIAL.yml --ask-v -e "configFile=config/liste_brocade_zoning.yml" -e "Replace=true"
# Cmd Line    : ansible-playbook awx2awx-CREDENTIAL.yml --ask-v -e "configFile=config/liste_brocade_zoning.yml" -e "Import=true"
# Cmd Line    : ansible-playbook awx2awx-CREDENTIAL.yml --ask-v -e "configFile=config/liste_brocade_zoning.yml" -e "Export=true Replace=true" -e "Import=true"
# Cmd Line    :
#             :
# Extra Vars  : 
# Extra Vars  : configFile (Path+File)
# Extra Vars  : Export     ( false (default) | true )
# Extra Vars  : Replace    ( false (default) |true)
# Extra Vars  : Import     ( false (default) | true )
# Extra Vars  : Destroy    ( false (default) | true )
# Extra Vars  : State      ( present (default) | absent )
# Extra Vars  : Debug      ( false (default) | true )

# File        : Section of configuration file
#             : An Example can be found in : config/skeletor.yml
#
# configFile  : my_export_name ( sufix for file name )
#             : my_import_name ( sufix for file name )
#             : my_export_awx  ( int | prod | build | proto )
#             : my_import_awx  ( int | prod | build | proto )
# credential  : my_credential               ( List of name)
#             : my_replacement_credential:
#             : my_regex_credential:
# project     : my_project:                 ( List of project name)
#             : my_replacement_project:
#             : my_regex_project: []
# job_template: my_job_template:            ( List of job name)
#             : my_replacement_job:
#             : my_regex_job:
# workflow    : my_workflow:                ( List of worlflow name)
#             : my_replacement_workflow:
#             : my_replacement_workflow_inventory:
#             : my_regex_workflow:

# Description : For deletion of an object, use thoses vars
#             : ( Import or Export ) to designate the awx targetto delete oject
#             : ( Destroy ) for delete, without State this is a Dry Run fonction
#             : ( State ) for confir the action
#             : Ex: for full deletion , Import=true Destroy=true State=absent
# Workflow AWX: Setting Extra Variable
#             : configFile: config/My_List_export_awx_object
#             : Export: true
#             : Replace: true
#             : Import: true
#-----------------------------------------------------------------------------------
# awx_host_export_from: https://awxaas-build.atom.eclair.local
# awx_user_export_from: I21660O
# awx_password_export_from: xxxxxxxxxxx
# # ---
# awx_host_import_to: https://awxaas-proto.atom.eclair.local
# awx_user_import_to: I21660O
# awx_password_import_to: xxxxxxxxxxx!
# # ---
# awx_host_int_export_from: http://lxin0853pv
# awx_user_int_export_from: I21660O
# awx_password_int_export_from: xxxxxxxxxxx!
# # ---
# awx_host_prod_import_to: http://lxpr0853pv
# awx_user_prod_import_to: I21660O
# awx_password_prod_import_to: xxxxxxxxxxx!
# 
#-----------------------------------------------------------------------------------
```
-----------
Exemple:
```yaml
my_export_name: "export-lxin0853pv_brocade_zoning-"
my_import_name: "import-proto_atom_brocade_zoning-"
my_export_awx: "int"
my_import_awx: "proto"
```
```yaml
my_credential:
  - git-brocade-token
  - Brocade_vault
my_replacement_credential:
  git-brocade-token:
    - key: "organization"
      value: "ATOM-Stockage"
    - key: "name"
      value: "P_BROCADE_GIT_TOKEN"
  Brocade_vault:
    - key: "organization"
      value: "ATOM-Stockage"
    - key: "name"
      value: "P_BROCADE_VAULT"
my_regex_credential:
  git-brocade-token:
    - reg: 'git-brocade-acces-token'
      rpl: 'P_BROCADE_GIT_TOKEN'
  Brocade_vault: []
```
```yaml
my_project:
  - P-brocade
my_replacement_project:
  - key: "name"
    value: "P_BROCADE"
  - key: "credential"
    value: "P_BROCADE_GIT_TOKEN"
  - key: "organization"
    value: "ATOM-Stockage"
  - key: "scm_url"
    value: "https://www.iscm.app.private/pole-storageteam/brocade.git"
my_regex_project: []
```
```yaml
my_job_template:
  - P_JOB_BROCADE_1-zonning-check-csv
  - P_JOB_BROCADE_2-zonning-check-cfg
  - P_JOB_BROCADE_3-zonning-backup-commit
  - P_JOB_BROCADE_3-zonning-backup-create
  - P_JOB_BROCADE_3-zonning-backup-rollback
  - P_JOB_BROCADE_4-zonning-aliases-create
  - P_JOB_BROCADE_4-zonning-aliases-delete
  - P_JOB_BROCADE_4-zonning-aliases-rollback
  - P_JOB_BROCADE_5-zonning-zones-create
  - P_JOB_BROCADE_5-zonning-zones-delete
  - P_JOB_BROCADE_5-zonning-zones-rollback
  - P_JOB_BROCADE_6-zonning-zoneset-add
  - P_JOB_BROCADE_6-zonning-zoneset-delete
  - P_JOB_BROCADE_6-zonning-zoneset-rollback
  - P_JOB_BROCADE_7-zonning-WF-exit-error
  - P_JOB_BROCADE_7-zonning-WF-exit-success
my_replacement_job:
  - key: "project"
    value: "P_BROCADE"
my_regex_job:
  - reg: 'zonning'
    rpl: 'zoning'
  - reg: 'Brocade_vault'
    rpl: 'P_BROCADE_VAULT'
  - reg: ': null,'
    rpl: ': 0,'
  - reg: '\[\\n'
    rpl: '['
  - reg: '\\n ]'
    rpl: ' ]'
  - reg: '{\\n'
    rpl: '{'
  - reg: '\\n}'
    rpl: '}'
  - reg: ',\\n'
    rpl: ','
```
```yaml
my_workflow:
  - P_WFL_BROCADE_zonning-create
  - P_WFL_BROCADE_zonning-delete
my_replacement_workflow:
  - key: "organization"
    value: "ATOM-Stockage"
my_replacement_workflow_inventory:
  - key: "inventory"
    value: "SwitchTestDev"
my_regex_workflow:
  - reg: 'zonning'
    rpl: 'zoning'
  - reg: ': null,'
    rpl: ': 0,'
  - reg: '\[\\n'
    rpl: '['
  - reg: '\\n ]'
    rpl: ' ]'
  - reg: '{\\n'
    rpl: '{'
  - reg: '\\n}'
    rpl: '}'
  - reg: ',\\n'
    rpl: ','
```