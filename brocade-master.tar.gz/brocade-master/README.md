# BROCADE

- [BROCADE](#brocade)
- [Liste des rôles :](#liste-des-rôles-)
- [Liste des playbooks rôle :: Zoning ::](#liste-des-playbooks-rôle--zoning-)
- [Liste des playbooks rôle :: Extract ::](#liste-des-playbooks-rôle--extract-)
- [Liste des playbooks rôle :: Input ::](#liste-des-playbooks-rôle--input-)
- [Liste des playbooks rôle :: Switch ::](#liste-des-playbooks-rôle--switch-)
- [Common Extra Vars (Default)](#common-extra-vars-default)
- [Arbo](#arbo)
- [S3](#s3)
  - [## Dépôt fichiers de configuration :: s3 ls s3://a2s-brocade/config/](#-dépôt-fichiers-de-configuration--s3-ls-s3a2s-brocadeconfig)
  - [## Dépôt fichiers de travail :: s3 ls s3://a2s-brocade/files/](#-dépôt-fichiers-de-travail--s3-ls-s3a2s-brocadefiles)
  - [## Dépôt fichiers de référence pour vérification avec SRE :: s3 ls s3://a2s-brocade/refs/](#-dépôt-fichiers-de-référence-pour-vérification-avec-sre--s3-ls-s3a2s-brocaderefs)
  - [## Dépôt fichiers de test pour test interne :: s3 ls s3://a2s-brocade/zoning/](#-dépôt-fichiers-de-test-pour-test-interne--s3-ls-s3a2s-brocadezoning)

---
# Liste des rôles :

* `zoning` ( Create / Delete San Brocade Zone )
* `switch` ( Health Check Switch )
* `input` ( Using Front End VRA for create zoning )
* `extract` ( Get zones and aliases configuration in a zoneset )
* `common` ( Used by all playbook )
* `gitshare` ( Local rôle for management git access )
* `sendmail` ( Local rôle for send email )
* `storagegrid` ( Local rôle for management S3 )
* `multiplecomparefile` ( Local rôle for SRE )
* `simplecomparefile` ( Local rôle for SRE )
  
---

# Liste des playbooks rôle :: Zoning :: 

1. `zoning-check-consistency-csv-file.yml`
2. `zoning-check-cfg.yml`
3. `zoning-backup-cfg.yml`
4. `zoning-aliases.yml`
5. `zoning-zones.yml`
6. `zoning-config-zoneset.yml`
7. `zoning-WF-exit-on-error.yml`
8. `zoning-WF-exit-on-success.yml`
   
---

# Liste des playbooks rôle :: Extract ::

1. `extract-config.yml`
   
---

# Liste des playbooks rôle :: Input ::

1. `input-zoning-received.yml`
2. `input-zoning-init-fabric1.yml`
3. `input-zoning-init-fabric2.yml`
   
---

# Liste des playbooks rôle :: Switch ::

1. `switch-create-refsFiles.yml`
2. `switch-healthCheck.yml`
3. `switch-list-by-fabric.yml` ! Not running
4. `switch-WF-exit-on-error.yml` ! Not running
5. `switch-WF-exit-on-success.yml` ! Not running
   
--- 

# Common Extra Vars (Default)

```yaml
SendEmail: true
Verbose: false
VerboseRole: false
Debug: false 
DebugRole: false
DisplayDict: false
DisplayPreLoadVars: false
DisplayFosCmd: false 
ExecInWorkflow: true ( Mandatory True with AWX )
UseGitFileShare: false 
UseGridS3BucketBrocade: true 
UseUnityS3BucketBrocade: true
```
---
# Arbo

```
.
├── cleanUPfiles.yml
├── extract-config.yml
├── files
│   ├── local
│   │   ├── config
│   │   │   ├── config_fabric_env_list.json
│   │   │   ├── config_fabric_zoneset_list.json
│   │   │   ├── config_fabric_zoneset_list.json.bck
│   │   │   ├── config_fabric_zoneset_list.json.sav
│   │   │   └── VRA_fabric_env_list.json
│   │   ├── files
│   │   │   └── SRE-swd77-psshow-20220602-181357.json
│   │   ├── refs
│   │   │   └── SRE-swd77-psshow-20220602-181126.json
│   │   └── zoning
│   │       ├── zoning2.csv
│   │       ├── zoning.csv
│   │       ├── zoning.csv.sav
│   │       ├── zoning.doublon1.csv
│   │       ├── zoning.doublon2.csv
│   │       ├── zoning.doublon3.csv
│   │       ├── zoning.Duplicate.csv
│   │       ├── zoning.Empty.csv
│   │       ├── zoning_from_git_dir.csv
│   │       ├── zoning.InvalidWWN.csv
│   │       ├── zoning.Missing.csv
│   │       ├── zoning.MultiSpaces.csv
│   │       ├── zoning.MultiSpacesInsideField.csv
│   │       ├── zoning.Prod1.csv
│   │       ├── zoning.Prod2.csv
│   │       ├── zoning.Prod3.csv
│   │       ├── zoning.Spaces.csv
│   │       ├── zoning.SpacesField.csv
│   │       ├── zoning.SpacesInsideField.csv
│   │       └── zoning.testprod.csv
│   ├── PRD_BucketBrocade
│   │   ├── config
│   │   │   ├── config_fabric_env_list.json
│   │   │   └── config_fabric_zoneset_list.json
│   │   ├── files
│   │   │   ├── alishow_ZS_TEST_DEV.stdout.txt
│   │   │   ├── alishow_ZS_TEST_FABRIC_20220629-110100.csv
│   │   │   ├── alishow_ZS_TEST_FABRIC.stdout.txt
│   │   │   ├── PRD-aliases-list-ZCA_BANALE.json
│   │   │   ├── PRD-aliases-list-ZCB_BANALE.json
│   │   │   ├── PRD-aliases-list-ZS_TEST_DEV.json
│   │   │   ├── PRD-aliases-list-ZS_TEST_FABRIC.json
│   │   │   ├── PRD-zones-list-ZS_TEST_DEV.json
│   │   │   ├── PRD-zones-list-ZS_TEST_FABRIC.json
│   │   │   ├── SRE-swd77-psshow-20220627-181308.diff
│   │   │   ├── SRE-swd77-psshow-20220627-181308.json
│   │   │   ├── zoneshow_ZS_TEST_DEV.stdout.txt
│   │   │   ├── zoneshow_ZS_TEST_FABRIC_20220629-110230.csv
│   │   │   └── zoneshow_ZS_TEST_FABRIC.stdout.txt
│   │   ├── refs
│   │   │   └── SRE-swd77-psshow-20220610-141331.json
│   │   ├── switch
│   │   └── zoning
│   ├── PRD_BucketProd
│   │   ├── SRE
│   │   │   └── reports
│   │   │       └── SRE-result-psshow-20220627-181308.html
│   │   └── ZONING
│   │       └── inputs
│   └── prod
│       └── SRE
│           └── reports
│               └── SRE-swd77-psshow-20220602-181357.html
├── group_vars
│   └── all
│       └── main.yml
├── host_vars
│   ├── FR1BRO01.yml
│   ├── FR1BRO02.yml
│   ├── FR2BRO01.yml
│   ├── FR2BRO02.yml
│   ├── SANABCC002.yml
│   ├── SANABCC004.yml
│   ├── SANABCC005.yml
│   ├── SANABCC006.yml
│   ├── SANABMC002.yml
│   ├── SANABMC004.yml
│   ├── SANABMC005.yml
│   ├── SANABMC006.yml
│   ├── SANADCLAB02.yml
│   ├── SANADMLAB02.yml
│   ├── SANAS01T01R0201.yml
│   ├── SANAS01T01R0202.yml
│   ├── SANAS01T03R0201.yml
│   ├── SANAS01T03R0202.yml
│   ├── SANAS01T05R0201.yml
│   ├── SANAS01T05R0202.yml
│   ├── SANAS01T07R0201.yml
│   ├── SANAS01T07R0202.yml
│   ├── SANAS01T09R0201.yml
│   ├── SANAS01T10R0201.yml
│   ├── SANAS01T11R0201.yml
│   ├── SANAS03T01R0201.yml
│   ├── SANAS03T01R0202.yml
│   ├── SANAS03T03R0201.yml
│   ├── SANAS03T04R0201.yml
│   ├── SANAS03T05R0201.yml
│   ├── SANAS03T07R0201.yml
│   ├── SANAS03T07R0202.yml
│   ├── SANAS08T05R0201.yml
│   ├── SANAS08T06R0201.yml
│   ├── SANAS08T07R0201.yml
│   ├── SANAS08T08R0201.yml
│   ├── SANAS09T05R0201.yml
│   ├── SANAS09T06R0201.yml
│   ├── SANAS09T07R0201.yml
│   ├── SANASF1T05R0101.yml
│   ├── SANASF8T02R0801.yml
│   ├── SANASF8T02R0802.yml
│   ├── SANBBCC002.yml
│   ├── SANBBCC004.yml
│   ├── SANBBCC005.yml
│   ├── SANBBCC006.yml
│   ├── SANBBMC002.yml
│   ├── SANBBMC004.yml
│   ├── SANBBMC005.yml
│   ├── SANBBMC006.yml
│   ├── SANBDCLAB02.yml
│   ├── SANBDMLAB02.yml
│   ├── SANBS01T01R1301.yml
│   ├── SANBS01T01R1302.yml
│   ├── SANBS01T03R1301.yml
│   ├── SANBS01T03R1302.yml
│   ├── SANBS01T05R1301.yml
│   ├── SANBS01T05R1302.yml
│   ├── SANBS01T07R1301.yml
│   ├── SANBS01T07R1302.yml
│   ├── SANBS01T09R1301.yml
│   ├── SANBS01T10R1301.yml
│   ├── SANBS01T11R1301.yml
│   ├── SANBS03T01R1301.yml
│   ├── SANBS03T01R1302.yml
│   ├── SANBS03T03R1301.yml
│   ├── SANBS03T04R1301.yml
│   ├── SANBS03T05R1301.yml
│   ├── SANBS03T07R1301.yml
│   ├── SANBS03T07R1302.yml
│   ├── SANBS08T05R1301.yml
│   ├── SANBS08T06R1301.yml
│   ├── SANBS08T07R1301.yml
│   ├── SANBS08T08R1301.yml
│   ├── SANBS09T05R1301.yml
│   ├── SANBS09T06R1301.yml
│   ├── SANBS09T07R1301.yml
│   ├── SANBSF2T05R0101.yml
│   ├── SANBSF9T02R0801.yml
│   ├── SANBSF9T02R0802.yml
│   ├── swd77.yml
│   └── swd78.yml
├── input-zoning-init-fabric1.yml
├── input-zoning-init-fabric2.yml
├── input-zoning-received.yml
├── README.md
├── README_WLF_zonning.md
├── roles
│   ├── common
│   │   ├── defaults
│   │   │   └── main.yml
│   │   ├── handlers
│   │   │   └── main.yml
│   │   ├── meta
│   │   │   └── main.yml
│   │   ├── README.md
│   │   ├── tasks
│   │   │   ├── checkStateExtraVars.yml
│   │   │   ├── checkWorkflowExtraVars.yml
│   │   │   ├── displayCommonExtraVars.yml
│   │   │   ├── displayContextExtraVars.yml
│   │   │   ├── displayVars.yml
│   │   │   ├── getShareDepotFiles.yml
│   │   │   ├── importVarsDirAndFiles.yml
│   │   │   ├── importVarsDirectories.yml
│   │   │   ├── importVarsFiles.yml
│   │   │   ├── loadCsvFileForZonning.yml
│   │   │   ├── loadFabricConfiguration.yml
│   │   │   ├── loadPreTasksConfig.yml
│   │   │   ├── loadSwitchConfiguration.yml
│   │   │   ├── main.yml
│   │   │   └── pushShareDepotFiles.yml
│   │   ├── tests
│   │   │   ├── inventory
│   │   │   └── test.yml
│   │   └── vars
│   │       ├── config_FabricJsonFileName.yml
│   │       ├── config_GitShareFileUsage.yml
│   │       ├── config_GridS3PRDBucketBrocade.yml
│   │       ├── config_LocalCloneFileUsage.yml
│   │       ├── config_UnityS3PRDBucketBrocade.yml
│   │       └── mail-secret.yml.sav
│   ├── extract
│   │   ├── defaults
│   │   │   └── main.yml
│   │   ├── files
│   │   │   ├── input-survey-create-host-zonning.json
│   │   │   ├── input-survey-host.json
│   │   │   ├── input-survey-zoneset.json
│   │   │   └── input-survey-ZS.json
│   │   ├── handlers
│   │   │   └── main.yml
│   │   ├── library
│   │   │   └── brocade_fos_command.py
│   │   ├── meta
│   │   │   └── main.yml
│   │   ├── README.md
│   │   ├── tasks
│   │   │   ├── format-alishow.yml
│   │   │   ├── format-zoneshow.yml
│   │   │   ├── get-alishow.yml
│   │   │   ├── get-zoneshow.yml
│   │   │   └── main.yml
│   │   ├── templates
│   │   │   ├── input-survey-create-host-zonning.j2
│   │   │   ├── input-survey-create-host-zonning.j2.mono
│   │   │   ├── input-survey-host.j2
│   │   │   └── input-survey-zoneset.j2
│   │   ├── tests
│   │   │   ├── inventory
│   │   │   └── test.yml
│   │   └── vars
│   │       ├── config_default.yml
│   │       └── main.yml
│   ├── gitshare
│   │   ├── defaults
│   │   │   └── main.yml
│   │   ├── handlers
│   │   │   └── main.yml
│   │   ├── meta
│   │   │   └── main.yml
│   │   ├── README.md
│   │   ├── tasks
│   │   │   ├── main.yml
│   │   │   ├── pull-gitshare.yml
│   │   │   └── push-gitshare.yml
│   │   ├── tests
│   │   │   ├── inventory
│   │   │   └── test.yml
│   │   └── vars
│   │       ├── git-secrets.yml
│   │       └── main.yml
│   ├── input
│   │   ├── defaults
│   │   │   └── main.yml
│   │   ├── files
│   │   │   ├── input-survey-create-host-zonning.json
│   │   │   ├── input-survey-host.json
│   │   │   ├── input-survey-zoneset.json
│   │   │   ├── input-survey-ZS.json
│   │   │   └── input-zoning-received-mail-body.html
│   │   ├── handlers
│   │   │   └── main.yml
│   │   ├── meta
│   │   │   └── main.yml
│   │   ├── README.md
│   │   ├── tasks
│   │   │   ├── create-host-zonning.yml
│   │   │   ├── create-host-zonning.yml.sav
│   │   │   ├── create-survey-to-host-zonning.yml
│   │   │   ├── main.yml
│   │   │   └── push-survey-create-host-zonning.yml
│   │   ├── templates
│   │   │   ├── input-survey-create-host-zonning.j2
│   │   │   ├── input-survey-create-host-zonning.j2.mono
│   │   │   ├── input-survey-host.j2
│   │   │   ├── input-survey-zoneset.j2
│   │   │   └── input-zoning-received-mail-body.j2
│   │   ├── tests
│   │   │   ├── inventory
│   │   │   └── test.yml
│   │   └── vars
│   │       ├── config_InputZoningReceived.yml
│   │       ├── config_InputZonningReceived.yml
│   │       └── main.yml
│   ├── multiplecomparefile
│   │   ├── files
│   │   │   ├── REF-swd77-psshow.json
│   │   │   ├── simpleReport.comp
│   │   │   ├── simpleReport.html
│   │   │   └── SRC-swd77-psshow.json
│   │   ├── tasks
│   │   │   └── main.yml
│   │   ├── templates
│   │   │   ├── MultipleFooterReport.j2
│   │   │   ├── MultipleHeaderReport.j2
│   │   │   ├── MultiplerowReport.j2
│   │   │   └── simpleReport.j2
│   │   └── vars
│   │       └── main.yml
│   ├── sendmail
│   │   ├── defaults
│   │   │   └── main.yml
│   │   ├── handlers
│   │   │   └── main.yml
│   │   ├── meta
│   │   │   └── main.yml
│   │   ├── README.md
│   │   ├── tasks
│   │   │   └── main.yml
│   │   ├── templates
│   │   │   └── MailTest.txt
│   │   ├── tests
│   │   │   ├── inventory
│   │   │   └── test.yml
│   │   └── vars
│   │       ├── main.yml
│   │       └── sendmail-secrets.yml
│   ├── simplecomparefile
│   │   ├── files
│   │   │   ├── REF-swd77-psshow.json
│   │   │   ├── simpleReport.comp
│   │   │   ├── simpleReport.html
│   │   │   └── SRC-swd77-psshow.json
│   │   ├── tasks
│   │   │   ├── main.yml
│   │   │   └── reportFile.yml
│   │   ├── templates
│   │   │   └── simpleReport.j2
│   │   └── vars
│   │       └── main.yml
│   ├── storagegrid
│   │   ├── defaults
│   │   │   └── main.yml
│   │   ├── handlers
│   │   │   └── main.yml
│   │   ├── meta
│   │   │   └── main.yml
│   │   ├── README.md
│   │   ├── tasks
│   │   │   ├── list-files.yml
│   │   │   └── main.yml
│   │   ├── tests
│   │   │   ├── inventory
│   │   │   └── test.yml
│   │   └── vars
│   │       ├── main.yml
│   │       ├── main.yml.ori
│   │       ├── storagegrid-secrets.yml
│   │       ├── storagegrid-secrets.yml.old
│   │       └── storagegrid-secrets.yml.ori
│   ├── switch
│   │   ├── defaults
│   │   │   └── main.yml
│   │   ├── files
│   │   │   └── switch-healthCheck-mail-body.html
│   │   ├── handlers
│   │   │   └── main.yml
│   │   ├── library
│   │   │   └── brocade_fos_command.py
│   │   ├── meta
│   │   │   └── main.yml
│   │   ├── README.md
│   │   ├── tasks
│   │   │   ├── change-password-brocade.yml
│   │   │   ├── common-comp-fos-cmd.yml
│   │   │   ├── common-exec-fos-cmd.yml
│   │   │   ├── comp-fos-cmd.yml
│   │   │   ├── create-user-brocade.yml
│   │   │   ├── downloadRefsFileFromS3.yml
│   │   │   ├── exec-fos-cmd.yml
│   │   │   ├── init-sw-conf.yml
│   │   │   ├── listAllRefsFileFromS3.yml
│   │   │   ├── list-comp-fos-cmd.yml
│   │   │   ├── listRefsFileFromS3.yml.multi
│   │   │   ├── searchSwitchConfigByName.yml
│   │   │   └── searchSwitchConfigForEatchFabric.yml
│   │   ├── templates
│   │   │   ├── switch-create-itself-config.j2
│   │   │   ├── switch-CreateRefsFiles-mail-body.j2
│   │   │   ├── switch-CreateRefsFiles-mail-body.j2.sav
│   │   │   ├── switch-healthCheck-mail-body.j2
│   │   │   └── switch-healthCheck-mail-body.j2.sav
│   │   └── vars
│   │       ├── config_SwitchCreateRefsFiles.yml
│   │       ├── config_SwitchHealthCheck.yml
│   │       └── main.yml
│   └── zoning
│       ├── defaults
│       │   └── main.yml
│       ├── files
│       │   ├── tsto_rsa
│       │   └── tsto_rsa.pub
│       ├── handlers
│       │   └── main.yml
│       ├── library
│       │   └── brocade_fos_command.py
│       ├── meta
│       │   └── main.yml
│       ├── README.md
│       ├── tasks
│       │   ├── aliases-cmd.yml
│       │   ├── aliases-count.yml
│       │   ├── aliases-show.yml
│       │   ├── backup-Cfg-Act.yml
│       │   ├── backup-Cfg-Act.yml.sav
│       │   ├── check-Cfg-Fid-Zact-Trans.yml
│       │   ├── config-cmd.yml
│       │   ├── config-count.yml
│       │   ├── config-show.yml
│       │   ├── main.yml
│       │   ├── zones-cmd.yml
│       │   ├── zones-count.yml
│       │   └── zones-show.yml
│       └── vars
│           └── main.yml
├── s3_ls_refs.yml
├── switch-create-brocade-users.yml
├── switch-create-refsFiles.yml
├── switch-healthCheck.yml
├── switch-list-by-fabric.yml
├── zoning-aliases.yml
├── zoning-backup-cfg.yml
├── zoning-check-cfg.yml
├── zoning-check-consistency-csv-file.yml
├── zoning-config-zoneset.yml
├── zoning-WF-exit-on-error.yml
├── zoning-WF-exit-on-success.yml
└── zoning-zones.yml

```
---
# S3
## Dépôt fichiers de configuration :: s3 ls s3://a2s-brocade/config/
---
> C'est fichiers ne sont plus utilisés, \
> ils sont présent dans le git
```bash 
s3 ls s3://a2s-brocade/config/
2022-06-07 10:48:39        755 VRA_fabric_env_list.json
2022-06-07 10:48:39       1235 VRA_fabric_zoneset_list.json
2022-09-28 03:46:20        898 config_fabric_env_list.json
2022-09-28 03:46:20       8698 config_fabric_zoneset_list.json
```
---
## Dépôt fichiers de travail :: s3 ls s3://a2s-brocade/files/
---
> Sont présent les fichiers `PRD...` d'extraction de la configuration des alias et des zones par fabric \
> au  forma JSON pour une utilisation ultérieure, \
> et au format txt `alishow... et zoneshow...` qui est l'extraction brut des informations
> > Les fichiers `SRE...` sont des fichiers de travail \
> > *.comp* est le résultat de la comparaison (indique des différences) \
> > *.diff* est le résultat des différence (une taille de 0 indique d'il n'y a pas de différences) \
> > *.json* est le fichier qui dot étre comparé

```bash
s3 ls s3://a2s-brocade/files/
2022-09-25 01:02:53      30578 PRD-aliases-list-ZCA_BANALE.json
2022-09-24 01:16:50       1891 PRD-aliases-list-ZCA_REPLI.json
2022-09-23 01:31:53       5864 PRD-aliases-list-ZCA_SEBC.json
2022-09-28 01:46:56       4077 PRD-aliases-list-ZCA_SENSIBLE.json
2022-09-24 02:02:25      11640 PRD-aliases-list-ZCA_SVG.json
2022-09-28 03:02:47      30919 PRD-aliases-list-ZCB_BANALE.json
2022-09-28 03:16:59       1954 PRD-aliases-list-ZCB_REPLI.json
2022-09-28 03:32:19       5777 PRD-aliases-list-ZCB_SEBC.json
2022-09-28 03:47:05       5971 PRD-aliases-list-ZCB_SENSIBLE.json
2022-09-12 04:02:31      11275 PRD-aliases-list-ZCB_SVG.json
2022-06-27 18:15:41      29485 PRD-aliases-list-ZS_TEST_FABRIC.json
2022-09-25 01:10:41     186010 PRD-zones-list-ZCA_BANALE.json
2022-09-24 01:16:57       1394 PRD-zones-list-ZCA_REPLI.json
2022-09-23 01:32:57      65367 PRD-zones-list-ZCA_SEBC.json
2022-09-28 01:47:16      22939 PRD-zones-list-ZCA_SENSIBLE.json
2022-09-24 02:02:43      25377 PRD-zones-list-ZCA_SVG.json
2022-09-28 03:10:33     183308 PRD-zones-list-ZCB_BANALE.json
2022-09-28 03:17:06       1394 PRD-zones-list-ZCB_REPLI.json
2022-09-28 03:33:24      68344 PRD-zones-list-ZCB_SEBC.json
2022-09-28 03:47:20      16001 PRD-zones-list-ZCB_SENSIBLE.json
2022-09-12 04:02:47      20121 PRD-zones-list-ZCB_SVG.json
2022-06-27 18:15:42     225852 PRD-zones-list-ZS_TEST_FABRIC.json

2022-09-25 01:01:19      39371 alishow_ZCA_BANALE.stdout.txt
2022-09-24 01:16:10       2702 alishow_ZCA_REPLI.stdout.txt
2022-09-23 01:31:08       7781 alishow_ZCA_SEBC.stdout.txt
2022-09-28 01:46:08       5512 alishow_ZCA_SENSIBLE.stdout.txt
2022-09-24 02:01:34      15103 alishow_ZCA_SVG.stdout.txt
2022-09-28 03:01:17      39803 alishow_ZCB_BANALE.stdout.txt
2022-09-28 03:16:18       2778 alishow_ZCB_REPLI.stdout.txt
2022-09-28 03:31:32       7668 alishow_ZCB_SEBC.stdout.txt
2022-09-28 03:46:20       7926 alishow_ZCB_SENSIBLE.stdout.txt
2022-09-12 04:01:36      14634 alishow_ZCB_SVG.stdout.txt
2022-09-25 01:02:53     178631 zoneshow_ZCA_BANALE.stdout.txt
2022-09-24 01:16:50       1635 zoneshow_ZCA_REPLI.stdout.txt
2022-09-23 01:31:52      63000 zoneshow_ZCA_SEBC.stdout.txt
2022-09-28 01:46:53      22228 zoneshow_ZCA_SENSIBLE.stdout.txt
2022-09-24 02:02:25      24102 zoneshow_ZCA_SVG.stdout.txt
2022-09-28 03:02:47     176031 zoneshow_ZCB_BANALE.stdout.txt
2022-09-28 03:16:58       1635 zoneshow_ZCB_REPLI.stdout.txt
2022-09-28 03:32:19      65681 zoneshow_ZCB_SEBC.stdout.txt
2022-09-28 03:47:05      15534 zoneshow_ZCB_SENSIBLE.stdout.txt
2022-09-12 04:02:31      19376 zoneshow_ZCB_SVG.stdout.txt


2022-06-22 17:11:31        326 SRE-SANAS01T03R0202-fanshow-20220622-145615.comp
2022-06-22 17:11:32        145 SRE-SANAS01T03R0202-fanshow-20220622-145615.diff
2022-06-22 17:11:34        319 SRE-SANAS01T03R0202-fanshow-20220622-145615.json
2022-06-20 15:07:09          0 SRE-swd77-psshow-20220610-172006.diff
2022-06-20 15:07:09        324 SRE-swd77-psshow-20220610-172006.json
```
---
## Dépôt fichiers de référence pour vérification avec SRE :: s3 ls s3://a2s-brocade/refs/
---
```bash
s3 ls s3://a2s-brocade/refs/
2022-09-15 17:08:57        306 SRE-SANAS01T01R0201-psshow-20220914-141553.json
2022-09-15 17:08:57        306 SRE-SANAS01T01R0202-psshow-20220914-141553.json
2022-09-15 17:08:57        306 SRE-SANAS01T03R0201-psshow-20220914-141553.json
```
---
## Dépôt fichiers de test pour test interne :: s3 ls s3://a2s-brocade/zoning/
---
```bash
s3 ls s3://a2s-brocade/zoning/
2022-06-16 19:20:47        492 zoning_from_git_dir.csv
```
---
