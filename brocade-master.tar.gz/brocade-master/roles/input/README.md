# Input VRA Configuration with AWX:

- [Input VRA Configuration with AWX:](#input-vra-configuration-with-awx)
  - [- Command curl pour test](#--command-curl-pour-test)
  - [Liste des Workflows](#liste-des-workflows)
    - [Workflows with Extra Vars configuration](#workflows-with-extra-vars-configuration)
  - [Liste des Jobs Template](#liste-des-jobs-template)
  - [Job Template Extra Vars (Mandatory)](#job-template-extra-vars-mandatory)
  - [Liste des IDs API.](#liste-des-ids-api)
  - [> A definir pour Tower ...](#-a-definir-pour-tower-)
- [Configuration JSON pour VRA](#configuration-json-pour-vra)
- [S3](#s3)
  - [Fichier de configuration des environements :: s3://a2s-vra/config/](#fichier-de-configuration-des-environements--s3a2s-vraconfig)
  - [## Fichier de configuration des alias pour l'interface VRA :: s3://a2s-vra/files/](#-fichier-de-configuration-des-alias-pour-linterface-vra--s3a2s-vrafiles)
  - [Fichier de configuration du zoning à executer Input :: s3 ls s3://a2s-vra/ZONING/inputs/](#fichier-de-configuration-du-zoning-à-executer-input--s3-ls-s3a2s-vrazoninginputs)
- [Output](#output)
- [Command curl pour test](#command-curl-pour-test)
---

## Liste des Workflows

---

1. `P_WFL_BROCADE_VRA-input-zoning-host`  
2. `P_WFL_BROCADE_VRA_zoning-create`  

  > P_WFL_BROCADE_VRA_zoning-create_ is the\
  > same as BROCADE_zoning-create without SURVEY

  ---

  ### Workflows with Extra Vars configuration
  
  ---

  `P_WFL_BROCADE_VRA-input-zoning-host` 

  > **Mandatory on GUI**\
  > Prompt on launch => ON

  ```yaml
  AcceptCGU: 'No'
  ArrayName_1: ArrayName
  ArrayName_2: ArrayName
  HostName_1: None
  HostName_2: None
  NewHostName_1: NewHostName
  NewHostName_2: NewHostName
  NewHostWwn_1: '10:00:00:00:00:00:00:01'
  NewHostWwn_2: '10:00:00:00:00:00:00:02'
  UserEmailSender: ''
  UserID: ''
  WorkflowInfo: Testing received Myvar
  WorkflowJobID: 365
  ZoneSetName_1: FabricA
  ZoneSetName_2: FabricB
  ```
---

## Liste des Jobs Template

---

1. `P_JOB_BROCADE_VRA-1-input-zoning-received`
2. `P_JOB_BROCADE_VRA-2-input-zoning-init-fabric1`
3. `P_JOB_BROCADE_VRA-3-input-zoning-init-fabric2`
4. `P_JOB_BROCADE_VRA-1-input-zoning-WF-exit-on-success`
5. `P_JOB_BROCADE_VRA-1-input-zoning-WF-exit-on-error`

---

## Job Template Extra Vars (Mandatory)

---

|Job Template|Playbook|Status|
|:---|:---:|:---:|
|`P_JOB_BROCADE_VRA-1-input-zoning-received`|input-zoning-received.yml|present|
|`P_JOB_BROCADE_VRA-2-input-zoning-init-fabric1`|input-zoning-init-fabric1.yml|present|
|`P_JOB_BROCADE_VRA-2-input-zoning-init-fabric2`|input-zoning-init-fabric2.yml|present|
|`P_JOB_BROCADE_VRA-1-input-zoning-WF-exit-on-success`|input-zoning-WF-exit-on-success.yml|present|
|`P_JOB_BROCADE_VRA-1-input-zoning-WF-exit-on-error`|input-zoning-WF-exit-on-error.yml|present|

---

## Liste des IDs API.
> A definir pour Tower ...
---

|Environement|Host|Workflow_job_template ID|
|:---:|:---:|:---:|  
|Prod|lxpr0853pv|88|  
|Integration|awxaas-build.atom.eclair.local|365|

---

# Configuration JSON pour VRA
> Ce fichier est chargé automatiquement par VRA pour metttre a jour l'interface de saisie\
> s3://a2s-vra/config/VRA_fabric_env_list.json

---

```json
{
  "CGU": [
    "Une zone est constituée d'un alias host/HBA et d'un alias de baie.",
    "Chaque Alias à un WWN correspondant.",
    "Les WWN sont en minuscules.",
    "Une zone par Fabric (A et B) et par demande de Zonning.",
    "Renouvelez la demande plusieurs fois si multi-zone pour le même host/HBA.",
    "La demande de zonning constituent une modification de la Fabric correspondante.",
    "La demande de zonning est faite sous votre responsabilité."
  ],
  "list": [
    {
         "environment": "Fabric Prod BANALE HIGH (BANALE)",
         "name": "VF_BANALE_HIGH",
         "description": "ZoneSet A et ZoneSet B de BANALE HIGH",
         "zoneSetsNameList": ["ZCA_BANALE", "ZCB_BANALE"]
    },
    {
         "environment": "Fabric Prod BANALE SLOW (SENSIBLE)",
         "name": "VF_BANALE_SLOW",
         "description": "ZoneSet A et ZoneSet B de BANALE SLOW",
         "zoneSetsNameList": ["ZCA_SENSIBLE", "ZCB_SENSIBLE"]
    },
    {
         "environment": "Fabric Prod REPLI",
         "name": "VF_REPLI",
         "description": "Zone A et B de Prod fabric REPLI",
         "zoneSetsNameList": ["ZCA_REPLI", "ZCB_REPLI"]
    },
	{
         "environment": "Fabric Prod SEBC",
         "name": "VF_SEBC",
         "description": "Zone A et B de Prod fabric SEBC",
         "zoneSetsNameList": ["ZCA_SEBC", "ZCB_SEBC"]
    },
	{
         "environment": "Fabric Prod SVG",
         "name": "VF_SVG",
         "description": "Zone A et B de Prod fabric SVG",
         "zoneSetsNameList": ["ZCA_SVG", "ZCB_SVG"]
    }
  ]
}

```

# S3
## Fichier de configuration des environements :: s3://a2s-vra/config/

---

```bash
s3 ls s3://a2s-vra/config/
2022-07-07 10:53:01       1544 VRA_fabric_env_list.json
```

---

## Fichier de configuration des alias pour l'interface VRA :: s3://a2s-vra/files/
---
> Ces fichiers sont créés par l'extraction des données executées quotidiennement

```bash
2022-09-25 01:10:43      61303 VRA-aliases-list-ZCA_BANALE.json
2022-09-24 01:16:59       3758 VRA-aliases-list-ZCA_REPLI.json
2022-09-23 01:32:58      11162 VRA-aliases-list-ZCA_SEBC.json
2022-09-28 01:47:23       8200 VRA-aliases-list-ZCA_SENSIBLE.json
2022-09-24 02:02:44      23095 VRA-aliases-list-ZCA_SVG.json
2022-09-28 03:10:38      61973 VRA-aliases-list-ZCB_BANALE.json
2022-09-28 03:17:07       3868 VRA-aliases-list-ZCB_REPLI.json
2022-09-28 03:33:25      10981 VRA-aliases-list-ZCB_SEBC.json
2022-09-28 03:47:21      11974 VRA-aliases-list-ZCB_SENSIBLE.json
2022-09-12 04:02:48      22354 VRA-aliases-list-ZCB_SVG.json
2022-09-15 03:47:03        493 VRA-aliases-list-ZS_TEST_DEV.json
2022-09-15 03:47:03      58988 VRA-aliases-list-ZS_TEST_FABRIC.json
```

---
## Fichier de configuration du zoning à executer Input :: s3 ls s3://a2s-vra/ZONING/inputs/

---

```bash
s3 ls s3://a2s-vra/ZONING/inputs/
2022-07-07 10:32:42        139 zoning-VRA-D819493_OPR-23486-ZCA_BANALE_Active-20220707-083237.csv
2022-07-07 10:32:42        139 zoning-VRA-D819493_OPR-23486-ZCB_BANALE_Active-20220707-083237.csv
2022-07-07 15:22:31        139 zoning-VRA-D819493_OPR-23497-ZCA_BANALE_Active-20220707-132225.csv
2022-07-07 15:22:31        139 zoning-VRA-D819493_OPR-23497-ZCB_BANALE_Active-20220707-132225.csv
2022-07-07 15:55:20        139 zoning-VRA-D819493_OPR-23502-ZCA_BANALE_Active-20220707-135514.csv
2022-07-07 15:55:20        139 zoning-VRA-D819493_OPR-23502-ZCB_BANALE_Active-20220707-135514.csv
2022-07-07 16:25:38        139 zoning-VRA-D819493_OPR-23508-ZCA_BANALE_Active-20220707-142533.csv
2022-07-07 16:25:39        139 zoning-VRA-D819493_OPR-23508-ZCB_BANALE_Active-20220707-142533.csv
2022-07-07 16:45:21        139 zoning-VRA-D819493_OPR-23513-ZCA_SENSIBLE_Active-20220707-144516.csv
2022-07-07 16:45:21        149 zoning-VRA-D819493_OPR-23513-ZCB_SENSIBLE_Active-20220707-144516.csv
2022-07-07 17:14:16        139 zoning-VRA-D819493_OPR-23525-ZCA_BANALE_Active-20220707-151411.csv
2022-07-07 17:14:17        139 zoning-VRA-D819493_OPR-23525-ZCB_BANALE_Active-20220707-151411.csv
2022-07-07 17:28:34        139 zoning-VRA-D819493_OPR-23531-ZCA_BANALE-20220707-152829.csv
2022-07-07 17:28:34        139 zoning-VRA-D819493_OPR-23531-ZCB_BANALE-20220707-152829.csv
2022-07-07 17:34:34        132 zoning-VRA-D819493_OPR-23537-ZCA_BANALE-20220707-153428.csv
2022-07-07 17:34:34        132 zoning-VRA-D819493_OPR-23537-ZCB_BANALE-20220707-153428.csv
```
---

# Output

# Command curl pour test
```bash
curl -f -k --user i21660O:MonCanada123! \
-H 'Content-Type: application/json' \
-X POST "https://awxaas-build.atom.eclair.local/api/v2/workflow_job_templates/365/launch/" \
-d '{"extra_vars": "{ \"AcceptCGU\": \"Yes\", \"ZoneSetName_1\": \"ZCA_BANALE\", \"ZoneSetName_2\": \"ZCB_BANALE\", \"ArrayName_1\": \"NETAPP100_5A\", \"ArrayName_2\": \"NETAPP100_7B\", \"HostName_1\": \"BUVH105B_D4D6\", \"HostName_2\": \"BUVH105B_7EAC\", \"UserID\": \"D819493_OPR\", \"UserEmailSender\": \"D819493_OPR@intra-dev01.bdf-dev01.local\", \"State\": \"present\" }" }'

``` 