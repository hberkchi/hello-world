# Extract Zoning Configuration with AWX:
- [Extract Zoning Configuration with AWX:](#extract-zoning-configuration-with-awx)
  - [Liste des Jobs Template](#liste-des-jobs-template)
  - [Job Template Extra Vars (ConfigFabricName est Mandatory)](#job-template-extra-vars-configfabricname-est-mandatory)
  - [Job Template Extra Vars (Mandatory)](#job-template-extra-vars-mandatory)
- [S3](#s3)
  - [S3 :: Output :: s3://a2s-vra/files/](#s3--output--s3a2s-vrafiles)
  - [## S3 :: Output :: s3://a2s-brocade/files/](#-s3--output--s3a2s-brocadefiles)

## Liste des Jobs Template

---
* `P_JOB_BROCADE_extract-zoning-ZCA_BANALE`
* `P_JOB_BROCADE_extract-zoning-ZCA_REPLI`
* `P_JOB_BROCADE_extract-zoning-ZCA_SEBC`
* `P_JOB_BROCADE_extract-zoning-ZCA_SENSIBLE`
* `P_JOB_BROCADE_extract-zoning-ZCA_SVG`
* `P_JOB_BROCADE_extract-zoning-ZCB_BANALE`
* `P_JOB_BROCADE_extract-zoning-ZCB_REPLI`
* `P_JOB_BROCADE_extract-zoning-ZCB_SEBC`
* `P_JOB_BROCADE_extract-zoning-ZCB_SENSIBLE`
* `P_JOB_BROCADE_extract-zoning-ZCB_SVG`

---

## Job Template Extra Vars (ConfigFabricName est Mandatory)

---

|Job Template|ConfigFabricName|
|:---|:---|
|P_JOB_BROCADE_extract-zoning-ZCA_BANALE|ZCA_BANALE|
|P_JOB_BROCADE_extract-zoning-ZCA_REPLI|ZCA_REPLI
|P_JOB_BROCADE_extract-zoning-ZCA_SEBC|ZCA_SEBC
|P_JOB_BROCADE_extract-zoning-ZCA_SENSIBLE|ZCA_SENSIBLE
|P_JOB_BROCADE_extract-zoning-ZCA_SVG|ZCA_SVG
|P_JOB_BROCADE_extract-zoning-ZCB_BANALE|ZCB_BANALE
|P_JOB_BROCADE_extract-zoning-ZCB_REPLI|ZCB_REPLI
|P_JOB_BROCADE_extract-zoning-ZCB_SEBC|ZCB_SEBC
|P_JOB_BROCADE_extract-zoning-ZCB_SENSIBLE|ZCB_SENSIBLE
|P_JOB_BROCADE_extract-zoning-ZCB_SVG|ZCB_SVG

---

## Job Template Extra Vars (Mandatory)

---

> `Ces variables doivent existées pour chaque job template`

|Extra Vars|Value|
|:---:|:---:|
|ConfigFabricName|Voir au dessus
|State|present
|UseGitFileShare|false
|UseGridS3BucketBrocade|true

---
# S3

## S3 :: Output :: s3://a2s-vra/files/

---

```bash
2022-09-25 01:10:43      61303 VRA-aliases-list-ZCA_BANALE.json
2022-09-24 01:16:59       3758 VRA-aliases-list-ZCA_REPLI.json
2022-09-23 01:32:58      11162 VRA-aliases-list-ZCA_SEBC.json
2022-09-28 01:47:23       8200 VRA-aliases-list-ZCA_SENSIBLE.json
2022-09-24 02:02:44      23095 VRA-aliases-list-ZCA_SVG.json
2022-09-28 03:10:38      61973 VRA-aliases-list-ZCB_BANALE.json
2022-09-28 03:17:07       3868 VRA-aliases-list-ZCB_REPLI.json
2022-09-28 03:33:25      10981 VRA-aliases-list-ZCB_SEBC.json
2022-09-28 03:47:21      11974 VRA-aliases-list-ZCB_SENSIBLE.json
2022-09-12 04:02:48      22354 VRA-aliases-list-ZCB_SVG.json
2022-09-15 03:47:03        493 VRA-aliases-list-ZS_TEST_DEV.json
2022-09-15 03:47:03      58988 VRA-aliases-list-ZS_TEST_FABRIC.json
2022-09-25 01:10:43     284988 VRA-zones-list-ZCA_BANALE.json
2022-09-24 01:16:58       2082 VRA-zones-list-ZCA_REPLI.json
2022-09-23 01:32:58      95966 VRA-zones-list-ZCA_SEBC.json
2022-09-28 01:47:22      34861 VRA-zones-list-ZCA_SENSIBLE.json
2022-09-24 02:02:44      36296 VRA-zones-list-ZCA_SVG.json
2022-09-28 03:10:38     281127 VRA-zones-list-ZCB_BANALE.json
2022-09-28 03:17:07       2082 VRA-zones-list-ZCB_REPLI.json
2022-09-28 03:33:25     100250 VRA-zones-list-ZCB_SEBC.json
2022-09-28 03:47:21      24300 VRA-zones-list-ZCB_SENSIBLE.json
2022-09-12 04:02:48      29644 VRA-zones-list-ZCB_SVG.json
2022-09-15 03:47:03        107 VRA-zones-list-ZS_TEST_DEV.json
2022-09-15 03:47:03     345986 VRA-zones-list-ZS_TEST_FABRIC.json
```

## S3 :: Output :: s3://a2s-brocade/files/
---


```bash
s3 ls s3://a2s-brocade/files/
2022-09-25 01:02:53      30578 PRD-aliases-list-ZCA_BANALE.json
2022-09-24 01:16:50       1891 PRD-aliases-list-ZCA_REPLI.json
2022-09-23 01:31:53       5864 PRD-aliases-list-ZCA_SEBC.json
2022-09-28 01:46:56       4077 PRD-aliases-list-ZCA_SENSIBLE.json
2022-09-24 02:02:25      11640 PRD-aliases-list-ZCA_SVG.json
2022-09-28 03:02:47      30919 PRD-aliases-list-ZCB_BANALE.json
2022-09-28 03:16:59       1954 PRD-aliases-list-ZCB_REPLI.json
2022-09-28 03:32:19       5777 PRD-aliases-list-ZCB_SEBC.json
2022-09-28 03:47:05       5971 PRD-aliases-list-ZCB_SENSIBLE.json
2022-09-12 04:02:31      11275 PRD-aliases-list-ZCB_SVG.json
2022-06-27 18:15:41      29485 PRD-aliases-list-ZS_TEST_FABRIC.json
2022-09-25 01:10:41     186010 PRD-zones-list-ZCA_BANALE.json
2022-09-24 01:16:57       1394 PRD-zones-list-ZCA_REPLI.json
2022-09-23 01:32:57      65367 PRD-zones-list-ZCA_SEBC.json
2022-09-28 01:47:16      22939 PRD-zones-list-ZCA_SENSIBLE.json
2022-09-24 02:02:43      25377 PRD-zones-list-ZCA_SVG.json
2022-09-28 03:10:33     183308 PRD-zones-list-ZCB_BANALE.json
2022-09-28 03:17:06       1394 PRD-zones-list-ZCB_REPLI.json
2022-09-28 03:33:24      68344 PRD-zones-list-ZCB_SEBC.json
2022-09-28 03:47:20      16001 PRD-zones-list-ZCB_SENSIBLE.json
2022-09-12 04:02:47      20121 PRD-zones-list-ZCB_SVG.json
2022-06-27 18:15:42     225852 PRD-zones-list-ZS_TEST_FABRIC.json