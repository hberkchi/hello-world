# ZONING Configuration with AWX:
- [ZONING Configuration with AWX:](#zoning-configuration-with-awx)
  - [Liste des Workflows](#liste-des-workflows)
  - [Liste des Jobs Template](#liste-des-jobs-template)
  - [Workflow Extra Vars (Mandatory)](#workflow-extra-vars-mandatory)
- [Job Template Extra Vars (Mandatory)](#job-template-extra-vars-mandatory)
- [Job Template Extra Vars (Conditional)](#job-template-extra-vars-conditional)
- [Input csv file structure:](#input-csv-file-structure)
- [S3](#s3)
  - [S3 :: Input :: s3 ls s3://a2s-prod/ZONING/inputs/](#s3--input--s3-ls-s3a2s-prodzoninginputs)
- [Output](#output)

---
## Liste des Workflows

---
1. `P_WFL_BROCADE_zoning-create`
2. `P_WFL_BROCADE_zoning-delete`
3. `P_WFL_BROCADE_zoning-PreCheck`

---

## Liste des Jobs Template

---
1. `P_JOB_BROCADE_1-zoning-check-csv`
2. `P_JOB_BROCADE_2-zoning-check-cfg`
3. `P_JOB_BROCADE_3-zoning-backup-commit`
4. `P_JOB_BROCADE_3-zoning-backup-create`
5. `P_JOB_BROCADE_3-zoning-backup-rollback`
6. `P_JOB_BROCADE_4-zoning-aliases-create`
7. `P_JOB_BROCADE_4-zoning-aliases-delete`
8. `P_JOB_BROCADE_4-zoning-aliases-rollback`
9. `P_JOB_BROCADE_5-zoning-zones-create`
10. `P_JOB_BROCADE_5-zoning-zones-delete`
11. `P_JOB_BROCADE_5-zoning-zones-rollback`
12. `P_JOB_BROCADE_6-zoning-zoneset-add`
13. `P_JOB_BROCADE_6-zoning-zoneset-delete`
14. `P_JOB_BROCADE_6-zoning-zoneset-rollback`
15. `P_JOB_BROCADE_7-zoning-WF-exit-error`
16. `P_JOB_BROCADE_7-zoning-WF-exit-success`

---

## Workflow Extra Vars (Mandatory)

---
> Attention : All the variables defined in Workflow override the others in jobs template

```yaml
FileCsv: "zoning_from_git_dir.csv"
```

---

# Job Template Extra Vars (Mandatory)


|Job Template|Playbook|State|Additional|
|:---|:---:|:---:|:---:|
|`P_JOB_BROCADE_1-zoning-check-csv`|zoning-check-consistency-csv-file.yml|present|
|`P_JOB_BROCADE_2-zoning-check-cfg`|zoning-check-cfg.yml|present|
|`P_JOB_BROCADE_3-zoning-backup-commit`|zoning-backup-cfg.yml|commit|
|`P_JOB_BROCADE_3-zoning-backup-create`|zoning-backup-cfg.yml|present|
|`P_JOB_BROCADE_3-zoning-backup-rollback`|zoning-backup-cfg.yml|absent| RunRollback: true|
|`P_JOB_BROCADE_4-zoning-aliases-create`|zoning-aliases.yml|present|
|`P_JOB_BROCADE_4-zoning-aliases-delete`|zoning-aliases.yml|absent|
|`P_JOB_BROCADE_4-zoning-aliases-rollback`|zoning-aliases.yml|absent| RunRollback: true|
|`P_JOB_BROCADE_5-zoning-zones-create`|zoning-zones.yml|present|
|`P_JOB_BROCADE_5-zoning-zones-delete`|zoning-zones.yml|absent|
|`P_JOB_BROCADE_5-zoning-zones-rollback`|zoning-zones.yml|absent| RunRollback: true|
|`P_JOB_BROCADE_6-zoning-zoneset-add`|zoning-config-zoneset.yml|present|
|`P_JOB_BROCADE_6-zoning-zoneset-delete`|zoning-config-zoneset.yml|absent|
|`P_JOB_BROCADE_6-zoning-zoneset-rollback`|zoning-config-zoneset.yml|absent| RunRollback: true|
|`P_JOB_BROCADE_7-zoning-WF-exit-error`|zoning-WF-exit-on-error.yml
|`P_JOB_BROCADE_7-zoning-WF-exit-success`|zoning-WF-exit-on-success.yml

---

# Job Template Extra Vars (Conditional)


|Job Template|Playbook|state|Additional|
|:---:|:---:|:---:|:---:|
|`P_JOB_BROCADE_4-zoning-aliases-delete`|zoning-aliases.yml|absent|DeleteAlias: true|

> * __DeleteAlias__ ( (**Host** default) | any ) ( supprime les alias Host par default )\
   ( !!! **any** _supprime_ tous les alias Host et Array !!!) 
   
---

# Input csv file structure: 

> Field Separator (,)

|#|Col|Value|
|:---:|:---|:---|
|1|Alias Host Name|Host_1111|
|2|WWN Host Name|11:11:11:11:11:11:11:11|
|3|Alias Array Name|NETAPP_5678|
|4|WWN Array Name|12:34:56:78:12:34:56:78|
|5|ZoneSetName|ZS_TEST_DEV|
|6|FabricID|127|
|7|SwitchIP|127,10.193.128.247|
|8|Zone Name|Host_1111_NETAPP_5678|

```txt
Host_1111,11:11:11:11:11:11:11:11,NETAPP_5678,12:34:56:78:12:34:56:78,ZS_TEST_DEV,127,10.193.128.247,Host_1111_NETAPP_5678
Host_2222,22:22:22:22:22:22:22:22,NETAPP_5678,12:34:56:78:12:34:56:78,ZS_TEST_DEV,127,10.193.128.247,Host_2222_NETAPP_5678
Host_3333,33:33:33:33:33:33:33:33,NETAPP_5432,98:76:54:32:98:76:54:32,ZS_TEST_DEV,127,10.193.128.247,Host_3333_NETAPP_5432
Host_4444,44:44:44:44:44:44:44:44,NETAPP_0303,13:03:03:03:03:03:03:03,ZS_TEST_DEV,127,10.193.128.247,Host_4444_NETAPP_0303
```

---

# S3
## S3 :: Input :: s3 ls s3://a2s-prod/ZONING/inputs/ 

---

```bash
s3 ls s3://a2s-prod/ZONING/inputs/  
2022-06-21 14:44:35        492 zoning_from_git_dir.csv
2022-09-15 14:42:03        121 zoning_test_precheck.csv
```

---
# Output
