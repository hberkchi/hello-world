# SWITCH SRE Configuration with AWX:
- [SWITCH SRE Configuration with AWX:](#switch-sre-configuration-with-awx)
  - [Liste des Workflows](#liste-des-workflows)
  - [2. `P_WFL_BROCADE_switch-healthCheck`](#2-p_wfl_brocade_switch-healthcheck)
    - [Workflows with SURVEY configuration](#workflows-with-survey-configuration)
  - [* `P_WFL_BROCADE_switch-healthCheck`](#-p_wfl_brocade_switch-healthcheck)
  - [Liste des Jobs Template](#liste-des-jobs-template)
  - [4. `P_JOB_BROCADE_switch-list_by-fabricB` ! Not running](#4-p_job_brocade_switch-list_by-fabricb--not-running)
  - [Job Template Extra Vars (Mandatory)](#job-template-extra-vars-mandatory)
- [S3](#s3)
  - [S3 :: Output :: s3 ls s3://a2s-prod/SRE/reports/](#s3--output--s3-ls-s3a2s-prodsrereports)
  - [## S3 :: Output :: s3 ls s3://a2s-brocade/refs/](#-s3--output--s3-ls-s3a2s-brocaderefs)

---
## Liste des Workflows

---
1. `P_WFL_BROCADE_switch-createRefsFiles`
2. `P_WFL_BROCADE_switch-healthCheck`
---

### Workflows with SURVEY configuration

---
* `P_WFL_BROCADE_switch-createRefsFiles`  
* `P_WFL_BROCADE_switch-healthCheck`
---

> ### Toutes les chams sont mandatory dans le survey AWX

---

|Champ de saisie|Variable|Value|Default|
|:---|:---:|:---:|:---:|
|LISTE DES SWITCHS PAR NOM|Use_switch|true/false|false|
|NOMS DES SWITCHS BROCADE|List_switchs[]|[ sw1 , sw2 , ... ]|swd77|
|LISTE DES SWITCHS PAR NOM DE FABRIC OU SALLE|Use_fabric|true/false|true|
|NOM DES FABRICS OU SALLES|List_fabrics[]|[ ZS_BANALE , VF_Repli , ... ]||
|SCOPE|Scope[]|( psshow, mapsdb, slotshow,s witchshow, fanshow, sensorshow, all )|psshow|

---

## Liste des Jobs Template

---
1. `P_JOB_BROCADE_switch-createRefsFiles`
2. `P_JOB_BROCADE_switch-healthCheck`
3. `P_JOB_BROCADE_switch-list-by-fabricA` ! Not running
4. `P_JOB_BROCADE_switch-list_by-fabricB` ! Not running
---

## Job Template Extra Vars (Mandatory)

---

|Job Template|Playbook|State|UseGridS3BucketBrocade|SendEmail|
|:---|:---:|:---:|:---:|:---:|
|`P_JOB_BROCADE_switch-createRefsFiles`|switch-create-refsFiles.yml|present|true|true|
|`P_JOB_BROCADE_switch-healthCheck`|switch-healthCheck.yml|present|true|true|

---

# S3
## S3 :: Output :: s3 ls s3://a2s-prod/SRE/reports/

> Contient les fichiers `html` envoyés par mail pour vérification des résultats

```bash
s3 ls s3://a2s-prod/SRE/reports/
2022-06-22 17:11:22       3512 SRE-SANAS01T03R0202-fanshow-20220622-145615.html
2022-07-22 19:03:24      11054 SRE-SANAS01T03R0202-mapsdb-20220722-164527.html
2022-06-02 20:04:24       3412 SRE-SANAS01T03R0202-psshow-20220602-175937.html
2022-06-02 20:15:30       3412 SRE-SANAS01T03R0202-psshow-20220602-181150.html
2022-06-03 10:39:58       3412 SRE-SANAS01T03R0202-psshow-20220603-083713.html
```
## S3 :: Output :: s3 ls s3://a2s-brocade/refs/
---
```bash
s3 ls s3://a2s-brocade/refs/
2022-09-15 17:08:57        306 SRE-SANAS01T01R0201-psshow-20220914-141553.json
2022-09-15 17:08:57        306 SRE-SANAS01T01R0202-psshow-20220914-141553.json
2022-09-15 17:08:57        306 SRE-SANAS01T03R0201-psshow-20220914-141553.json
```