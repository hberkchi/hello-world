$user_id = $args[0]                         # AD greoup or AD user 
$domain = $args[1]                          # AD

#$user = get-aduser $user_id -server $domain 
$user = Get-ADUser -Server $domain  -Filter "SamAccountName -eq '$user_id'"

if($user)
 {
   $sid = $user.SID.Value
   write-host $user.SID.Value
 }
else
 {
   echo "utilisateur introuvable : $user_id"
 }

