$identity = $args[0]                    # AD greoup or AD user 
$op = $args[1]                          # operation : set, add, remove
$fileSystemRights = $args[2]            # Rights ( Fullcontrol, Read, Write, ... )
$ACLtype = $args[3]                     # Acl type ( Allow, Deny, ... )
$path = $args[4]                        # 
$Inheritance = "ContainerInherit, ObjectInherit"
$Propagation = "None"
#$path = '\\10.104.188.182\qtree2' 
#$path = '\\10.104.188.182\zs-fs2quota01'

############### mount path on a drive ######################
$User = $args[5]
$pass = $args[6]
$PWord = ConvertTo-SecureString -String $pass -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord
$Drive_L = (New-SmbMapping -LocalPath "*" -RemotePath $path -UserName $Credential.UserName -Password $Credential.GetNetworkCredential().Password).LocalPath
net use /delete $Drive_L
###########################################################

$NewAcl = Get-Acl -Path $path 

# Create new rule
$Inheritance, $Propagation 
#$fileSystemAccessRuleArgumentList = $identity, $fileSystemRights, $ACLtype
$fileSystemAccessRuleArgumentList = $identity, $fileSystemRights, $Inheritance, $Propagation, $ACLtype
$fileSystemAccessRule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $fileSystemAccessRuleArgumentList

# Apply new rule
if($op -eq "set") { $NewAcl.SetAccessRule($fileSystemAccessRule) }
if($op -eq "add") { $NewAcl.AddAccessRule($fileSystemAccessRule) }
if($op -eq "remove") { $NewAcl.RemoveAccessRule($fileSystemAccessRule) }
Set-Acl -Path $path -AclObject $NewAcl

##################################
