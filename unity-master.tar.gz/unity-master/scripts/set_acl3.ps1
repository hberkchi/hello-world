$identity = $args[0]                    # AD greoup or AD user 
$op = $args[1]                          # operation : set, add, remove
$fileSystemRights = $args[2]            # Rights ( Fullcontrol, Read, Write, ... )
$ACLtype = $args[3]                     # Acl type ( Allow, Deny, ... )
$path = $args[4]                        # 
$Inheritance = "ContainerInherit, ObjectInherit"
$Propagation = "None"
#path = '\\10.104.188.182\qtree2' 
$path2 = '\\10.104.188.182\zs-fs2quota01'

############### mount path on a drive ######################
$User = $args[5]
$pass = $args[6]



write-host "path : $path"
write-host "path2 : $path2"


