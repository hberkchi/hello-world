# scripts/mount_mkdir.ps1 {{ share }} {{ user }} {{ pass }} {{ gls }} {{ tech }}"

$path = $args[0]
$User= $args[1]
$pass= $args[2]
$GLS= $args[3]
$TECH= $args[4]
#$User = "domain\username"
Write-Output "bla bla :"$path
$PWord = ConvertTo-SecureString -String $pass -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord
New-PSDrive -Name "K" -PSProvider "FileSystem" -Root $path -Credential $Credential -Persist
Get-ChildItem K:\
New-Item -ItemType "directory" -Path "k:\DATA", "k:\DIR", "k:\PUBLI"
if($GLS -eq "oui") { New-Item -ItemType "directory" -Path "k:\GLS" }
if($TECH -eq "oui") { New-Item -ItemType "directory" -Path "k:\TECH" }
Get-ChildItem K:\
# Remove-Item "k:\DATA", "k:\DIR", "k:\PUBLI", "k:\GLS", "k:\TECH"
Remove-PSDrive "K"
