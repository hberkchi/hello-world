
- [Introduction](#introduction)
- [Utilisation du code](#utilisation-du-code)
- [Prerequis](#prerequis)
## Introduction
Ce repo contient les playbook développés dans le cadre de l'automatisation des opérations d’administration MASTOC LOT2 (baies NAS Unity)

Les playbook ont été développés :
-	En se basant sur la collection Ansible dellemc.unity développée par le constructeur
-	En respectant les règles d’ingénieries établies par l’équipe d’architectes SOCLE STOCKAGE.
-	Pour être utilisés à partir d’ATARI (Ansible Automation Platform) :
	- Production : https://www.atari.app.private
	- Développement :  https://www.dv01.atari.app.private


## Utilisation du code

1- clone

2- install storops
	 pip3 install storops --user  ( if pip not istalled  GOTO : "install pip"  )

3- run with : 
          ksh ans.ksh <playbook>

4- for doc :
	export ANSIBLE_COLLECTIONS_PATHS=$ANSIBLE_COLLECTIONS_PATHS:./collections	        
	ansible-doc dellemc.unity.info
	
List of dellemc.unity functions :

	- volume
	- nfs
	- nasserver
	- tree_quota
	- storagepool
	- filesystem
	- info
	- user_quota
	- filesystem_snapshot
	- snapshot
	- smbshare
	- host
	- consistencygroup
	- snapshotschedule


install pip :

	- Be root 
	- create file epel7-latest.repo if needed :
		cat /etc/yum.repos.d/epel7-latest.repo
		[epel7-latest]
		name=epel7-latest
		enabled=1
		baseurl=http://r-isis.unix.intra.bdf.local/repo/epel7-latest
		gpgcheck=0

	- install python36 
		yum install python36

	- install pip3 
		yum install python36-pip.noarch


use pip :

	- Be yourself (not root)
	- create file ~/.pip/pip.conf

		cat ~/.pip/pip.conf
		[global]
		cert = /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem
		index-url = https://artifactory-build.sofact.bdf.dns.eclair.local/artifactory/api/pypi/pypi/simple

	- install pip 
		pip3 install storops --user


## Prerequis

Binaires :

	- Ansible 
	- python 3.X

Librairies Python 3.X :

	- boto3
	- paramiko
	- libselinux
	- xmltodict
	- requests
	- storops
	- pywinrm
                
Collections Ansible :

	- ansible.windows
	- dellemc.unity

