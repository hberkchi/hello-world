# PSC_FOR_PROD

Ce projet permet de réaliser les différents contrôles liés aux PSC des composants stockage NETAPP CDOT 9.6

# SOMMAIRE

- [Composants controlés](#Composants_controlés)
- [Fonctionnement](#fonctionnement)
- [Arborescence](#Arborescence)
- [Roles](#roles)
    - [Détail des roles](#détail-des-roles)
        - [PSC_DELETE_FILE_OUTPUT](#role-PSC_DELETE_FILE_OUTPUT)
        - [PSC_DUR_02](#role-psc_dur_02)
        - [PSC_ACC_03](#role-psc_acc_03)
        - [PSC_TRACE_01](#role-psc_trace_01)
        - [PSC_ACC_04](#role-psc_acc_04)
        - [PSC_TRACE_02](#role-psc_trace_02)
        - [PSC_DUR_03](#role-psc_dur_03)
        - [PSC_COMPARE](#role-psc_compare)
        - [PSC_REPORT](#role-psc_report)
        - [PSC_MAIL](#role-psc_mail)

## Composants controlés

* AFF8080
* FAS8200
* ESAP
* Switch Brocade Back End Netapp

## Fonctionnement

Le playbook principal fait appel à des rôles dans lesquels se trouvent les commandes à exécuter pour chacun des contrôles. Il fait appel à un inventaire Ansible "inventory" qui repertorie la totalité des composants Netapp.
Des variables générales, globales s'appliquent à tous les équipements et se trouvent dans les fichiers:
* group_vars/all
* host_vars/all

La collection utilisée est : na_ontap (collection officielle Netapp)




## Arborescence

```text
PSC_FOR_PROD
├── playbook_psc.yml    <-- Playbook principal -->
├── inventory   <-- fichier d'inventaire -->
├── roles       <-- liste des rôles developpés pour la PSC_NETAPP -->
│   ├── PSC_XX_XX  
│   │   ├── vars 
│   │   │   └── main.yml   <-- Fichier contenant les variables pour le role -->
│   │   └── tasks
│   │   │   └── main.yml   <-- fichier contenant les commandes à exécuter sur les noeuds Netapp -->
├── group_vars      <-- Répertoire regroupant les fichiers contenant les variables liées à des groupes de l'inventaire -->
│   ├── all         <-- Fichier contenant les variables qui s'appliquent à tous les groupes de l'inventaire -->
│   ├── group_XXX   <-- Fichier contenant les variables qui s'appliquent aux groupes XXX de l'inventaire -->
│   └── group_YYY   <-- Fichier contenant les variables qui s'appliquent aux groupes YYY de l'inventaire -->
├── host_vars       <-- Répertoire regroupant les fichiers contenant les variables liées aux hosts de l'inventaire -->
│   ├── all         <-- Fichier contenant les variables qui s'appliquent à tous les hosts de l'inventaire -->
│   ├── host_X      <-- Fichier contenant les variables qui s'appliquent à l'host X de l'inventaire -->
│   └── host_Y      <-- Fichier contenant les variables qui s'appliquent à l'host Y de l'inventaire -->
├── PSC_COMPARE.json
├── report_psc.j2
├── report_psc_log.j2
├── PSC_RAPPORT
├── PSC_RAPPORT_LOG

```

## Appel des roles

On a un playbook principal : **playbook_psc.yml** qui appelle les rôles créés.

```yaml
- hosts: all 
  gather_facts: no
  force_handlers: true
  roles:
    - { role: PSC_DELETE_FILE_OUTPUT }
    - { role: PSC_DUR_02, when: "inventory_hostname in groups['netapp-test']" }   # Netapp CDOT
    - { role: PSC_ACC_03, when: "inventory_hostname in groups['netapp-test']"}   # Netapp CDOT 
    - { role: PSC_TRACE_01, when: "inventory_hostname in groups['netapp-test']" } # Netapp CDOT
    - { role: PSC_ACC_04, when: "inventory_hostname in groups['switch-test']" }   # Netapp SW BE
    - { role: PSC_TRACE_02, when: "inventory_hostname in groups['switch-test']" } # Netapp SW BE
    - { role: PSC_DUR_03, when:  "inventory_hostname in groups['switch-test']" }   # Netapp SW BE
    - { role: PSC_COMPARE, run_once: true } 
    - { role: PSC_REPORT, run_once: true }
    - { role: PSC_MAIL, run_once: true }

```

Pour certains roles, une condition est donnée : _when: "inventory_hostname in groups['switch-test']"_

Cela permet de n'exécuter le rôle qui sur un groupe de l'inventaire.

## Roles 

* PSC_DELETE_FILE_OUTPUT
* PSC_DUR_02   # Netapp CDOT
* PSC_ACC_03   # Netapp CDOT 
* PSC_TRACE_01 # Netapp CDOT
* PSC_ACC_04   # Netapp SW BE
* PSC_TRACE_02 # Netapp SW BE
* PSC_DUR_03   # Netapp SW BE
* PSC_COMPARE 
* PSC_REPORT
* PSC_MAIL


### Détail des roles


#### role : PSC_DELETE_FILE_OUTPUT

##### **Description fonctionnelle**

Ce rôle sert à supprimer les fichiers de sortie créés lors de l'exécution précédente.

Variable: Pas de variable.


##### **Description technique**

```yaml
- name: Suppression du dossier contenant les rapports
       shell: | 
           rm -f files/output/1-PSC/netapp_to_compare/*
           rm -f files/output/1-PSC/netapp_no_compare/*
```

#### role : PSC_DUR_02

##### **Description fonctionnelle**

Ce rôle réalise le contrôle DUR_02

Périmètre : Netapp CDOT

Variables:
* inventory_hostname: IP du cluster Netapp (magic variable)
* netapp_user: Identifiant du compte admin
* netapp_password: Mot de passe du compte admin

Commandes:
* date;security protocol show; security config show
* date; system services firewall policy show -vserver VSERVER -policy mgmt -service ssh
* date; system services web show

Module utilisé de la collection:
- na_ontap_command

Paramètre à définir obligatoirement:
- Hostname 
- username
- password
- privilège: les privilèges necessaires pour exécuter la/les commande/s
- https: on utilise le https donc paramètre à définir sur "true/yes"
- validate-certs: notre certificat n'est pas valide, la valeur est à positionner sur "no"
- command: liste des commandes à exécuter


##### **Description technique**

Bloc 1: Execution d'une commande sur un cluster Netapp

```yaml
- name: TRAITEMENT DUR 2 COMMANDE 1 
      na_ontap_command:
        hostname: "{{ inventory_hostname }}"
        username: "{{ netapp_user }}"
        password: "{{ netapp_password }}"
        privilege: 'advanced'
        https: true
        validate_certs: false
        return_dict: true
        command: ['date;security protocol show; security config show']
      register: psc_command_1_return
```

Bloc 2 : Enregistrement des output dans un fichier

```yaml
- name: CREATION DU FICHIER OUTPUT DUR 2 COMMANDE 1
      copy:
        content: "{{  psc_command_1_return.msg.stdout_lines |to_nice_json(indent=2) }}"
        dest: "files/output/1-PSC/netapp_to_compare/{{ vserver_admin }}-DUR02-services.check.{{ date }}"
```
Les roles : 
- PSC_ACC_03
- PSC_TRACE_01
- PSC_ACC_04
- PSC_TRACE_02
- PSC_DUR_03

Les rôles précédemments cités suivent le même fonctionnement, utilisent la même collection **na_ontap** et le même module **na_ontap_command**.




#### role : PSC_COMPARE

##### Description fonctionnelle


##### Description technique

bloc 1 : Suppression des fichiers pour n'avoir que les rapports de l'exécutino en cours

```yaml
- name: Suppression du dossier contenant les rapports
  file:
    state: absent
    path: PSC_RAPPORT

- name: Creation du dossier contenant les rapports
  file:
    state: directory
    path: PSC_RAPPORT

- name: Suppression du dossier contenant les rapports de type LOG
  file:
    state: absent
    path: PSC_RAPPORT_LOG

- name: Creation du dossier contenant les rapports de type LOG
  file:
    state: directory
    path: PSC_RAPPORT_LOG
```

bloc 2 : Création des variables contenant les fichiers de référence et les fichiers à comparer

```yaml
- name: Creation de la variable contenant les fichiers REF
  shell: "ls files/referentiels/1-PSC/netapp/* | egrep -v json"
  register: PSC_FILES_REF

- name: Creation de la variable contenant les fichiers OUTPUT 
  shell: "ls files/output/1-PSC/netapp_to_compare/* | egrep -v json"
  register: PSC_FILES_OUTPUT
```

bloc 3: Ajout des numéros de ligne aux fichiers

```yaml
- name: Ajout des numeros de ligne pour les outputs
  shell: "cat -n {{ item }} > {{ item }}_tmp_file ; cat {{ item }}_tmp_file > {{ item }}; rm {{ item }}_*"
  with_items:
    - "{{ PSC_FILES_OUTPUT.stdout_lines }}"
```



#### role : PSC_REPORT

##### Description fonctionnelle


##### Description technique

bloc 1 : Création des variables pour effectuer les comparaisons Référentiel vs Output.

```yaml
- name: Creation de la variable contenant les rapports
  shell: "ls PSC_RAPPORT/*"
  register: PSC_RAPPORT

- name: 
  shell: "ls PSC_RAPPORT_LOG/*"
  register: PSC_RAPPORT_LOG

- name: Creation de la variable contenant les referentiels
  shell:  "ls files/referentiels/1-PSC/netapp/* | egrep -v json"
  register: PSC_REF
```

bloc 2 :  Création des fichiers rapports de type : Comparaison

```yaml
- name: Jinja2 file PSC COMPARAISON
  template:
    src: report_psc.j2
    dest: "{{ item.0 }}.html"
  with_together: 
    - "{{ PSC_RAPPORT.stdout_lines }}"
    - "{{ PSC_REF.stdout_lines }}"
  when: item.0 | regex_replace('^(.*/)', '') | regex_replace('[0-9]{4}.*[0-9]', '') ==  item.1 | regex_replace('^(.*/)', '') | regex_replace('[0-9]{4}.*[0-9]', '')
  changed_when: ( PSC_RAPPORT.stdout_lines | list | length ) != ( PSC_REF.stdout_lines | list | length )
```

bloc 3 : Création des fichiers rapports de type : Affichage simple (pour les logs uniquement)

```yaml
- name: Jinja2 file PSC LOG
  template:
    src: report_psc_log.j2
    dest: "{{ item }}.html"
  with_items: "{{ PSC_RAPPORT_LOG.stdout_lines }}"
```

#### role : PSC_MAIL

##### Description fonctionnelle

Variables pour le bloc 2 :

* host: IP ou alias DNS du serveur de mail
* username: Compte de service pour l'envoi de mail (a2s_user_smtp)
* password: Mot de passe du compte de service (a2s_user_smtp)
* port: port smtp (25)
* from: adresse mail source 
* to: adresse mail de destination
* subject: Objet du mail 
* secure: Protocole pour le chiffrement du mail (starttls)
* subtype: format du mail (html)
* body: Corp du mail
* attach: fichiers à joindre au mail

**Tous ces paramètres/variables sont à définir.**

##### Description technique

bloc 1 : Création d'une variable regroupant les fichiers à passer en pièces jointes.

```yaml
- shell: |
      ls PSC_RAPPORT/*.html
      ls PSC_RAPPORT_LOG/*.html
register: html_files
```

bloc 2 : Envoi du mail 

```yaml
- mail:
    host: pasap-secure.bdf.local
    username: "{{a2s_user_smtp}}"
    password: "{{a2s_user_smtp_pwd}}"
    port: 25
    from: a2s-pasap-asv@banque-france.fr
    to: damien.bourjade@banque-france.fr
    subject: "Rapport concernant les PSC" 
    secure: starttls
    subtype: html
    body: "Il s'agit d'un email envoyé depuis la plateforme AWX, merci de ne pas répondre."
    attach: "{{ html_files.stdout_lines | list | join(',') }}"
  delegate_to: localhost
```




